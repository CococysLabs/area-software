#include <math.h>
#include <iostream>

class hashTable{
    private:
        const float R = 0.618034;
        int M = 13;
        int elements;
        int *table;

    public:
        hashTable();

        void insert(int);
        //void search(int);
        void rehashing();
        void print();
        int linealProbe(int);
        int hashIndex(int);
        int dispersion(int);
};