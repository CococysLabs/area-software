#include "hash.h"

int main()
{
    hashTable table;
    table.insert(1);
    table.insert(2);
    table.insert(3);
    table.insert(4);
    table.insert(5);
    table.insert(6);
    table.insert(7);
    table.insert(8);
    table.insert(9);
    table.insert(10);

    table.print();
    return 0;
}