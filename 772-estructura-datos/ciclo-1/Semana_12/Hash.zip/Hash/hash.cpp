#include "hash.h"

hashTable::hashTable(){
    this->table = new int[M];

    for(int i = 0; i < M; i++){
        this->table[i] = -999;
    }
    this->elements = 0;
}

void hashTable::insert(int key){
    int pos = hashIndex(key);

    if(this->table[pos] != -999 && this->table[pos] != key){
        pos = linealProbe(pos);
    }

    this->table[pos] = key;
    this->elements++;

    if(((float)this->elements/M) > 0.75){
        int* temp = this->table;

        this->rehashing();

        for(int i = 0; i < M/2; i++){
            if(temp[i] != -999){
                this->insert(temp[i]);
            }
        }
    }
}

void hashTable::rehashing(){
    this->table = new int[M*2];
    this->elements = 0;
    this->M = M*2;

    for(int i = 0; i < M; i++){
        this->table[i] = -999;
    }
}

void hashTable::print(){
    for(int i = 0; i < M; i++){
        std::cout << table[i] << ", ";
    }
    std::cout << std::endl;
}

int hashTable::hashIndex(int key){
    return dispersion(key);
}

int hashTable::dispersion(int x){
    float t = R*x - floor(R*x);
    
    return floor(M*t);
}

int hashTable::linealProbe(int pos){
    while(this->table[pos] != -999){
        pos = pos + 1;
        pos = pos%M;
    }

    return pos;
}