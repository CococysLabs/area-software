import json

# Convertir diccionario Python a string JSON
def objeto_a_json():
    datos = {
        "nombre": "Juan",
        "edad": 30,
        "habilidades": ["Python", "JavaScript", "SQL"],
        "direccion": {
            "calle": "Calle Principal",
            "ciudad": "Ciudad Ejemplo"
        }
    }

    json_str = json.dumps(datos, indent=2)
    print(json_str)

    # Guardar en archivo
    with open("datos.json", "w") as archivo:
        json.dump(datos, archivo, indent=2)

# Convertir string JSON a objeto Python
def json_a_objeto():
    json_str = '{"nombre": "Ana", "edad": 25, "activo": true}'

    # Desde string
    datos = json.loads(json_str)
    print(f"Nombre: {datos['nombre']}, Edad: {datos['edad']}")

    # Desde archivo
    try:
        with open("datos.json", "r") as archivo:
            datos_archivo = json.load(archivo)
            print(f"Datos desde archivo: {datos_archivo['nombre']}")
    except FileNotFoundError:
        print("Archivo no encontrado")

if __name__ == "__main__":
    print("Convirtiendo objeto a JSON:")
    objeto_a_json()
    print("\nConvirtiendo JSON a objeto:")
    json_a_objeto()
