# Nota: Este código requiere la instalación de aiohttp
# pip install aiohttp

import asyncio
import aiohttp
import time

async def obtener_datos_async(session, url):
    async with session.get(url) as response:
        return await response.json()

async def main():
    # URLs de ejemplo
    urls = [
        f"https://jsonplaceholder.typicode.com/posts/{i}"
        for i in range(1, 11)
    ]

    inicio = time.time()

    async with aiohttp.ClientSession() as session:
        # Ejecutar todas las solicitudes en paralelo
        tareas = [obtener_datos_async(session, url) for url in urls]
        resultados = await asyncio.gather(*tareas)

        for i, resultado in enumerate(resultados):
            print(f"Resultado {i+1}: {resultado['title']}")

    fin = time.time()
    print(f"Tiempo total: {fin - inicio:.2f} segundos")

if __name__ == "__main__":
    asyncio.run(main())
