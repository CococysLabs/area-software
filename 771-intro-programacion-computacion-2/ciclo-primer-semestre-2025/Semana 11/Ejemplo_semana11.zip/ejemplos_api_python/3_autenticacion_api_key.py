import requests

def api_con_key():
    # Ejemplo con API key en header
    url = "https://api.ejemplo.com/datos"
    headers = {
        "X-API-Key": "tu_api_key_aqui"
    }

    # En un caso real, esta línea haría la solicitud
    # response = requests.get(url, headers=headers)
    print("Enviando solicitud con API key en header")

    # Ejemplo con API key como parámetro de consulta
    url_con_key = "https://api.ejemplo.com/datos?api_key=tu_api_key_aqui"
    # En un caso real, esta línea haría la solicitud
    # response_alt = requests.get(url_con_key)
    print("Enviando solicitud con API key en URL")

    return "Consulta con API key completada"

if __name__ == "__main__":
    print(api_con_key())
