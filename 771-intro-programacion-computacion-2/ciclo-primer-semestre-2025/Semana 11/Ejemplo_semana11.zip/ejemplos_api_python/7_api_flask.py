# Nota: Este código requiere la instalación de Flask y PyJWT
# pip install Flask PyJWT

from flask import Flask, request, jsonify
import jwt
import datetime
from functools import wraps

app = Flask(__name__)
app.config["SECRET_KEY"] = "clave_secreta_para_la_api"

# Base de datos simulada
usuarios = {
    "1": {"nombre": "Juan", "email": "juan@ejemplo.com"},
    "2": {"nombre": "Ana", "email": "ana@ejemplo.com"}
}

# Middleware para verificar token
def token_requerido(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get("Authorization")

        if not token:
            return jsonify({"mensaje": "Token faltante"}), 401

        try:
            # Eliminar "Bearer " si está presente
            if token.startswith("Bearer "):
                token = token[7:]

            datos = jwt.decode(token, app.config["SECRET_KEY"], algorithms=["HS256"])
            usuario_id = datos["sub"]

            if usuario_id not in usuarios:
                return jsonify({"mensaje": "Usuario no encontrado"}), 401

        except:
            return jsonify({"mensaje": "Token inválido"}), 401

        return f(usuario_id, *args, **kwargs)

    return decorated

# Ruta para login
@app.route("/login", methods=["POST"])
def login():
    datos = request.get_json()
    usuario_id = datos.get("id")

    if usuario_id not in usuarios:
        return jsonify({"mensaje": "Usuario no encontrado"}), 401

    # Generar token
    token = jwt.encode(
        {
            "sub": usuario_id,
            "iat": datetime.datetime.utcnow(),
            "exp": datetime.datetime.utcnow() + datetime.timedelta(minutes=30)
        },
        app.config["SECRET_KEY"],
        algorithm="HS256"
    )

    return jsonify({"token": token})

# Ruta protegida
@app.route("/perfil", methods=["GET"])
@token_requerido
def obtener_perfil(usuario_id):
    return jsonify(usuarios[usuario_id])

if __name__ == "__main__":
    print("Iniciando servidor Flask...")
    print("Para probar la API:")
    print("1. POST /login con JSON {'id': '1'}")
    print("2. GET /perfil con header 'Authorization: Bearer <token>'")
    app.run(debug=True)
