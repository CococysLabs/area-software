# Nota: Este código requiere la instalación de PyJWT
# pip install PyJWT

import jwt
import datetime

# Generar un token JWT
def generar_token(usuario_id):
    # Clave secreta para firmar el token (en producción, usar una clave segura)
    clave_secreta = "clave_muy_secreta"

    # Payload del token
    payload = {
        "sub": usuario_id,  # Subject (a quién pertenece el token)
        "iat": datetime.datetime.utcnow(),  # Issued At (cuándo se emitió)
        "exp": datetime.datetime.utcnow() + datetime.timedelta(hours=1),  # Expiración
        "roles": ["usuario"]  # Claims personalizados
    }

    # Generar el token
    token = jwt.encode(payload, clave_secreta, algorithm="HS256")
    return token

# Verificar y decodificar un token JWT
def verificar_token(token):
    try:
        clave_secreta = "clave_muy_secreta"
        # Decodificar y verificar el token
        payload = jwt.decode(token, clave_secreta, algorithms=["HS256"])
        return {"valido": True, "payload": payload}
    except jwt.ExpiredSignatureError:
        return {"valido": False, "error": "Token expirado"}
    except jwt.InvalidTokenError:
        return {"valido": False, "error": "Token inválido"}

if __name__ == "__main__":
    # Ejemplo de uso
    token = generar_token("usuario123")
    print(f"Token generado: {token}")

    # Verificar el token
    resultado = verificar_token(token)
    print(f"Resultado de verificación: {resultado}")
