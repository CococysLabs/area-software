# Nota: Este código requiere la instalación de jsonschema
# pip install jsonschema

import requests
from requests.exceptions import RequestException, Timeout, ConnectionError
import json

# Simulamos la importación de jsonschema para el ejemplo
# En un entorno real, usaríamos:
# from jsonschema import validate, ValidationError

# Esquema para validar datos JSON
esquema_usuario = {
    "type": "object",
    "properties": {
        "nombre": {"type": "string", "minLength": 3},
        "edad": {"type": "integer", "minimum": 18},
        "email": {"type": "string", "format": "email"}
    },
    "required": ["nombre", "email"]
}

# Simulación de la función validate para el ejemplo
def validate(instance, schema):
    # En un caso real, esta función validaría el JSON contra el esquema
    # Aquí simplemente simulamos algunos casos básicos
    if schema.get("required"):
        for campo in schema["required"]:
            if campo not in instance:
                raise Exception(f"Campo requerido faltante: {campo}")

    for campo, valor in instance.items():
        if campo in schema.get("properties", {}):
            prop = schema["properties"][campo]
            if prop.get("type") == "string" and not isinstance(valor, str):
                raise Exception(f"El campo {campo} debe ser una cadena")
            if prop.get("type") == "integer" and not isinstance(valor, int):
                raise Exception(f"El campo {campo} debe ser un entero")
            if prop.get("minLength") and isinstance(valor, str) and len(valor) < prop["minLength"]:
                raise Exception(f"El campo {campo} debe tener al menos {prop['minLength']} caracteres")
            if prop.get("minimum") and isinstance(valor, int) and valor < prop["minimum"]:
                raise Exception(f"El campo {campo} debe ser al menos {prop['minimum']}")

# Clase de excepción simulada
class ValidationError(Exception):
    pass

def validar_datos(datos, esquema):
    try:
        validate(instance=datos, schema=esquema)
        return True, None
    except Exception as e:
        return False, str(e)

def llamada_api_segura(url, metodo="GET", datos=None, timeout=5):
    try:
        # Validar datos si se proporcionan
        if datos and metodo in ["POST", "PUT", "PATCH"]:
            valido, error = validar_datos(datos, esquema_usuario)
            if not valido:
                return {"error": f"Datos inválidos: {error}"}

        # Realizar la solicitud con manejo de errores
        if metodo == "GET":
            response = requests.get(url, timeout=timeout)
        elif metodo == "POST":
            response = requests.post(url, json=datos, timeout=timeout)
        elif metodo == "PUT":
            response = requests.put(url, json=datos, timeout=timeout)
        elif metodo == "DELETE":
            response = requests.delete(url, timeout=timeout)
        else:
            return {"error": "Método HTTP no soportado"}

        # Verificar código de estado
        response.raise_for_status()

        # Intentar parsear la respuesta como JSON
        try:
            return response.json()
        except json.JSONDecodeError:
            return {"contenido": response.text}

    except Timeout:
        return {"error": "La solicitud excedió el tiempo de espera"}
    except ConnectionError:
        return {"error": "Error de conexión al servidor"}
    except RequestException as e:
        return {"error": f"Error en la solicitud: {str(e)}"}

if __name__ == "__main__":
    print("Ejemplo de llamada API segura:")
    resultado = llamada_api_segura("https://jsonplaceholder.typicode.com/users/1")
    print(resultado)

    print("\nEjemplo con datos inválidos:")
    datos_invalidos = {
        "nombre": "A",  # Muy corto
        "edad": 15      # Menor de 18
    }
    resultado_invalido = llamada_api_segura(
        "https://jsonplaceholder.typicode.com/users",
        metodo="POST",
        datos=datos_invalidos
    )
    print(resultado_invalido)
