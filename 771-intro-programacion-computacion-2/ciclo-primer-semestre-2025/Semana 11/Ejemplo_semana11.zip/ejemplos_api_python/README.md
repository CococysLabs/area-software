# Ejemplos de APIs y Seguridad Web en Python

Este repositorio contiene ejemplos prácticos de código Python relacionados con la interacción y seguridad en APIs y datos web.

## Contenido

1. **1_consumir_api_rest.py**: Ejemplos básicos de cómo consumir una API REST usando la biblioteca requests.
2. **2_analisis_json.py**: Manipulación y procesamiento de datos JSON.
3. **3_autenticacion_api_key.py**: Ejemplos de autenticación usando API Keys.
4. **4_oauth2_ejemplo.py**: Implementación de OAuth 2.0 para autenticación.
5. **5_asincrono_aiohttp.py**: Manejo de respuestas asíncronas usando asyncio y aiohttp.
6. **6_jwt_ejemplo.py**: Generación y verificación de tokens JWT.
7. **7_api_flask.py**: Creación de una API REST simple con Flask y autenticación JWT.
8. **8_validacion_errores.py**: Manejo de errores y validación de datos en solicitudes API.

## Requisitos

Para ejecutar estos ejemplos, necesitarás instalar las siguientes bibliotecas:

```bash
pip install requests flask pyjwt requests-oauthlib aiohttp jsonschema
```

## Uso

Cada archivo puede ejecutarse de forma independiente:

```bash
python 1_consumir_api_rest.py
```

Algunos ejemplos son solo ilustrativos y pueden requerir modificaciones para funcionar en un entorno real.

## Notas

- Los ejemplos de OAuth 2.0 y algunas otras funcionalidades requieren configuración adicional para funcionar en un entorno real.
- Las claves y tokens utilizados son ejemplos y no deben usarse en producción.
- Siempre sigue las mejores prácticas de seguridad al trabajar con APIs en entornos de producción.
