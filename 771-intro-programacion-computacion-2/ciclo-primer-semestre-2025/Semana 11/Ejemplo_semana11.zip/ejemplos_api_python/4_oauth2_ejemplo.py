# Nota: Este código requiere la instalación de requests-oauthlib
# pip install requests-oauthlib

from requests_oauthlib import OAuth2Session

def autenticar_oauth2():
    # Configuración
    client_id = "tu_client_id"
    client_secret = "tu_client_secret"
    authorization_base_url = "https://ejemplo.com/oauth/authorize"
    token_url = "https://ejemplo.com/oauth/token"

    # Crear sesión OAuth
    oauth = OAuth2Session(client_id, redirect_uri="https://tu-app.com/callback")

    # Obtener URL de autorización
    authorization_url, state = oauth.authorization_url(authorization_base_url)
    print(f"Por favor, visita esta URL para autorizar: {authorization_url}")

    # En una aplicación real, el usuario visitaría la URL y sería redirigido
    # Aquí simulamos la redirección con un input
    redirect_response = input("Pega la URL de redirección completa aquí: ")

    # Obtener token de acceso
    token = oauth.fetch_token(
        token_url,
        client_secret=client_secret,
        authorization_response=redirect_response
    )

    # Usar el token para acceder a recursos protegidos
    return oauth.get("https://ejemplo.com/api/recurso-protegido").json()

if __name__ == "__main__":
    print("Este código es un ejemplo y requiere interacción del usuario.")
    print("En un entorno real, se ejecutaría en una aplicación web.")
