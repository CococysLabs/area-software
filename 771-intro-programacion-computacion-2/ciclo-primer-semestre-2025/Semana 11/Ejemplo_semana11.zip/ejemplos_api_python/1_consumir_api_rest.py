import requests

# Ejemplo básico de GET request
def obtener_datos():
    url = "https://jsonplaceholder.typicode.com/posts/1"
    response = requests.get(url)

    # Verificar si la solicitud fue exitosa
    if response.status_code == 200:
        return response.json()
    else:
        return f"Error: {response.status_code}"

# Ejemplo de POST request con JSON
def crear_recurso():
    url = "https://jsonplaceholder.typicode.com/posts"
    datos = {
        "title": "Nuevo post",
        "body": "Contenido del nuevo post",
        "userId": 1
    }

    response = requests.post(url, json=datos)
    return response.json()

if __name__ == "__main__":
    print("Obteniendo datos:")
    print(obtener_datos())
    print("\nCreando recurso:")
    print(crear_recurso())
