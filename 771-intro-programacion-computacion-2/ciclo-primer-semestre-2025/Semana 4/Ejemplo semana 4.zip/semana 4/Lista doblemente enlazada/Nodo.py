class Tarea:
    def __init__(self, descripcion, prioridad, fecha):
        self.descripcion = descripcion
        self.prioridad = prioridad
        self.fecha = fecha
        self.siguiente = None
        self.anterior = None

