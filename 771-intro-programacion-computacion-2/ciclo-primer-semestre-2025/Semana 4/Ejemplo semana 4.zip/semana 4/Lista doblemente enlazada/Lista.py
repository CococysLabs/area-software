from Nodo import Tarea
import os
import webbrowser
from graphviz import Digraph

class ListaTareas:
    def __init__(self):
        self.cabeza = None
        self.ultimo = None
        self.tamanio = 0

    def AgregarTarea(self, descripcion, prioridad, fecha):
        nueva_tarea = Tarea(descripcion, prioridad, fecha)
        if self.tamanio == 0:
            self.cabeza = nueva_tarea
            self.ultimo = nueva_tarea
            self.tamanio += 1
        else:
            nueva_tarea.anterior = self.ultimo
            self.ultimo.siguiente = nueva_tarea
            self.ultimo = nueva_tarea
            self.tamanio += 1

    def imprimirLista(self):
        auxiliar: Tarea = self.cabeza
        for tarea in range(self.tamanio):
            print(f"Descripcion: {auxiliar.descripcion}, Prioridad: {auxiliar.prioridad}, Fecha Limite: {auxiliar.fecha}")
            auxiliar = auxiliar.siguiente

    def Graficar(self):
        contador=0
        graficar = "digraph G { \n"
        graficar += "node[shape=box] \n"
        graficar += "label= \"Tareas\" \n"
        auxiliar: Tarea = self.cabeza
        for tarea in range(self.tamanio):
            nodotarea = "tarea" + str(contador)
            contador +=1
            graficar += nodotarea + "[label=\"Descripcion: " + auxiliar.descripcion + "\n Prioridad: " + auxiliar.prioridad + "\n Fecha Limite: " + auxiliar.fecha+ " \"] \n"
            auxiliar = auxiliar.siguiente

        aux: Tarea = self.cabeza
        contador = 0
        while aux.siguiente is not None:
            nodotarea = "tarea" + str(contador)
            contadoranterior = contador-1
            contadorsiguiente = contador+1
            nodosiguientetarea = "tarea" + str(contadorsiguiente)
            nodoanteriortarea = "tarea" + str(contadoranterior)
            if aux == self.cabeza:
                graficar += "{rank=same; " + nodotarea + " ->" + nodosiguientetarea + "}\n";
            else:
                graficar += "{rank=same; " + nodotarea + " ->" + nodoanteriortarea + "}\n";
                graficar += "{rank=same; " + nodotarea + " ->" + nodosiguientetarea + "}\n";
            aux = aux.siguiente
            contador += 1

        graficar += "}"
        dot = "tareas.txt"
        with open(dot, 'w') as grafo:
            grafo.write(graficar)
        result = "tareas.pdf"
        os.system("dot -Tpdf " + dot + " -o " + result)
        webbrowser.open(result)