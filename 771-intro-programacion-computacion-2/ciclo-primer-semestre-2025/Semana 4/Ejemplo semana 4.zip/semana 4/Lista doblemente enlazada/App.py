import xml.etree.ElementTree as ET
from Lista import ListaTareas
from graphviz import Graph

Tareas = ListaTareas()
def menu():
    ruta = ""
    while True:
        print("------------Menu-------------------")
        print("1. Ingresar la ruta del XML")
        print("2. Procesar Archivo")
        print("3. Imprimir Datos")
        print("4. Graficar")
        print("5. Salir")
        eleccion = int(input("Escribe una opcion: "))

        if eleccion == 1:
            ruta = input("Escribe la ruta del XML: ")
            print(f"Ruta ingresada {ruta}")
        elif eleccion == 2:
            analizarArchivo(ruta)
        elif eleccion == 3:
            Tareas.imprimirLista()
        elif eleccion == 4:
            Tareas.Graficar()
        elif eleccion == 5:
            print("Saliendo")
            break
        else:
            print("Opcion invalida")


def analizarArchivo(ruta):
    try:
        tree = ET.parse(ruta)
        root = tree.getroot()
        alumnos = root.findall('tarea')
        for alumno in alumnos:
            descripcion = alumno.find('descripcion').text
            prioridad = alumno.find('prioridad').text
            fecha_limite = alumno.find('fecha_limite').text
            Tareas.AgregarTarea(descripcion, prioridad, fecha_limite)
        print("Tareas agregadas")
    except Exception as e:
        print(e)



if __name__ == "__main__":
    menu()