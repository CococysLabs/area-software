class Alumno:
    def __init__(self, nombre, carnet, carrera, edad):
        self.nombre = nombre
        self.carnet = carnet
        self.carrera = carrera
        self.edad = edad
        self.next = None