import xml.etree.ElementTree as ET
from Lista import ListaAlumno
from graphviz import Graph

Alumnos = ListaAlumno()
def menu():
    ruta = ""
    while True:
        print("------------Menu-------------------")
        print("1. Ingresar la ruta del XML")
        print("2. Procesar Archivo")
        print("3. Imprimir Datos")
        print("4. Graficar")
        print("5. Salir")
        eleccion = int(input("Escribe una opcion: "))

        if eleccion == 1:
            ruta = input("Escribe la ruta del XML: ")
            print(f"Ruta ingresada {ruta}")
        elif eleccion == 2:
            analizarArchivo(ruta)
        elif eleccion == 3:
            Alumnos.ImprimirLista()
        elif eleccion == 4:
            Alumnos.Graficar()
            Alumnos.GraficarLista()
        elif eleccion == 5:
            print("Saliendo")
            break
        else:
            print("Opcion invalida")


def analizarArchivo(ruta):
    try:
        tree = ET.parse(ruta)
        root = tree.getroot()
        alumnos = root.findall('alumno')
        for alumno in alumnos:
            nombre = alumno.find('nombre').text
            carnet = alumno.find('carnet').text
            carrera = alumno.find('carrera').text
            edad = alumno.find('edad').text
            Alumnos.AgregarAlumno(nombre, carnet, carrera, edad)
        print("Alumnos agregados")
    except Exception as e:
        print(e)



if __name__ == "__main__":
    menu()