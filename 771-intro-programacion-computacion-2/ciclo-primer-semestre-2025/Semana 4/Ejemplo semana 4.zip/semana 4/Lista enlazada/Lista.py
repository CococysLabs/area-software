from Nodo import Alumno
import os
import webbrowser
from graphviz import Digraph


class ListaAlumno:
    def __init__(self):
        self.primero = None
        self.ultimo = None
        self.tamanio = 0

    def AgregarAlumno(self, nombre, carnet, carrera, edad):
        nuevo_alumno = Alumno(nombre, carnet, carrera, edad)
        if self.primero is None:
            self.primero = nuevo_alumno
            self.ultimo = nuevo_alumno
            self.tamanio = self.tamanio + 1
        else:
            self.ultimo.next = nuevo_alumno
            self.ultimo = nuevo_alumno
            self.tamanio = self.tamanio + 1

    def ImprimirLista(self):
        auxiliar = self.primero
        for alumno in range(self.tamanio):
            print(
                f"Nombre: {auxiliar.nombre}, Carnet: {auxiliar.carnet}, Carrera: {auxiliar.carrera}, Edad: {auxiliar.edad}")
            auxiliar = auxiliar.next

    def EliminarLista(self):
        if self.primero is None:
            pass
        elif self.primero == self.ultimo:
            self.primero = None
            self.ultimo = None
        else:
            self.primero.siguiente = None
            self.primero = None
            self.ultimo = None

        self.tamanio = 0

    def Graficar(self):
        graficarlista = "digraph G { \n"
        graficarlista += "node[shape=box] \n"
        graficarlista += "label= \"Alumnos\" \n"
        auxiliar: Alumno = self.primero
        for alumno in range(self.tamanio):
            nodoalumno = "alumno" + auxiliar.carnet
            graficarlista += nodoalumno + "[label=\"Nombre: " + auxiliar.nombre + "\n Carnet: " + auxiliar.carnet + "\n Carrera: " + auxiliar.carrera + "\n Edad: " + auxiliar.edad + " \"] \n"
            auxiliar = auxiliar.next

        aux: Alumno = self.primero
        while aux.next is not None:
            nodoalumno = "alumno" + aux.carnet
            nodosiguientealumno = "alumno" + aux.next.carnet
            graficarlista += "{rank=same; " + nodoalumno + " ->" + nodosiguientealumno + "}\n";
            aux = aux.next
        graficarlista += "}"
        dot = "alumnos.txt"
        with open(dot, 'w') as grafo:
            grafo.write(graficarlista)
        result = "alumnos.pdf"
        os.system("dot -Tpdf " + dot + " -o " + result)
        webbrowser.open(result)

    def GraficarLista(self):
        dot = Digraph()
        auxiliar: Alumno = self.primero
        for alumno in range(self.tamanio):
            dot.node(auxiliar.carnet,
                     label=f'Nombre: {auxiliar.nombre}\n Carnet:  {auxiliar.carnet} \n Carrera: {auxiliar.carrera} \n Edad: {auxiliar.edad}')
            auxiliar = auxiliar.next

        aux: Alumno = self.primero
        while aux.next is not None:
            dot.edge(aux.carnet, aux.next.carnet)
            aux = aux.next

        dot.render('alumnos', format='png', cleanup=True, view=True)
        print("Gráfico generado")
