from NodoTienda import Tienda
import os
import webbrowser


class ListaTiendas:
    def __init__(self):
        self.cabeza = None
        self.ultimo = None
        self.tamanio = 0

    def agregarTienda(self, tienda, zona):
        nueva_tienda = Tienda(tienda, zona)
        if self.cabeza is None:
            self.cabeza = nueva_tienda
            self.ultimo = nueva_tienda
            self.cabeza.next = nueva_tienda
            self.tamanio += 1
        else:
            self.ultimo.next = nueva_tienda
            self.ultimo = nueva_tienda
            self.ultimo.next = self.cabeza
            self.tamanio += 1

    def imprimirTiendas(self):
        current: Tienda = self.cabeza
        while True:
            print(f"-------Tienda: {current.tienda}, Zona:  {current.zona}---------------")
            if current.next == self.cabeza:
                break
            current = current.next

    def Graficar(self):
        contador=0
        contador2=0
        graficar = "digraph G { \n"
        graficar += "node[shape=box] \n"
        graficar += "label= \"Tiendas y Envios\" \n"
        auxiliar: Tienda = self.cabeza
        for envio in range(self.tamanio):
            nodotienda = "tienda" + str(contador)
            contador += 1
            graficar += nodotienda + "[label=\"Tienda: "+auxiliar.tienda+" \nzona: " + auxiliar.zona + " \"] \n"
            auxiliar = auxiliar.next

        aux: Tienda = self.cabeza
        contador = 0
        for i in range(self.tamanio):
            nodotienda = "tienda" + str(contador)
            contadorsiguiente = contador + 1
            nodosiguientetienda = "tienda" + str(contadorsiguiente)
            if aux != self.ultimo:
                graficar += "{rank=same; " + nodotienda + " ->" + nodosiguientetienda + "}\n"
            if aux == self.ultimo:
                graficar += "{rank=same; " + nodotienda + " -> tienda0}\n"
            contador += 1
            aux = aux.next
        graficar += "}"
        dot = "tiendas.txt"
        with open(dot, 'w') as grafo:
            grafo.write(graficar)
        result = "tiendas.pdf"
        os.system("dot -Tpdf " + dot + " -o " + result)
        webbrowser.open(result)
