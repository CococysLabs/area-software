class Tienda:
    def __init__(self, tienda, zona):
        self.tienda = tienda
        self.zona = zona
        self.next = None
