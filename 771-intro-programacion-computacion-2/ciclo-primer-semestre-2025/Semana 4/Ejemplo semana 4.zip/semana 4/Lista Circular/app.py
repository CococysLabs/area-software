import xml.etree.ElementTree as ET
from ListaTiendas import ListaTiendas
from graphviz import Graph

Tiendas = ListaTiendas()
def menu():
    ruta = ""
    while True:
        print("------------Menu-------------------")
        print("1. Ingresar la ruta del XML")
        print("2. Procesar Archivo")
        print("3. Graficar")
        print("4. Salir")
        eleccion = int(input("Escribe una opcion: "))

        if eleccion == 1:
            ruta = input("Escribe la ruta del XML: ")
            print(f"Ruta ingresada {ruta}")
        elif eleccion == 2:
            analizarArchivo(ruta)
            Tiendas.imprimirTiendas()
        elif eleccion == 3:
            Tiendas.Graficar()
        elif eleccion == 4:
            print("Saliendo")
            break
        else:
            print("Opcion invalida")


def analizarArchivo(ruta):
    try:
        tree = ET.parse(ruta)
        root = tree.getroot()
        tiendas = root.findall('tiendas')
        for tienda in tiendas:
            nombre = tienda.find('tienda')
            zona = nombre.get('zona')
            Tiendas.agregarTienda(nombre.text, zona,)

    except Exception as e:
        print(e)

if __name__ == "__main__":
    menu()