class Tienda:
    def __init__(self, tienda, zona):
        self.tienda = tienda
        self.zona = zona
        self.envios = None
        self.next = None
