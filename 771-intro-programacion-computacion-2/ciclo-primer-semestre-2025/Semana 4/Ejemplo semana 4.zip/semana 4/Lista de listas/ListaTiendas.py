from NodoTienda import Tienda
import os
import webbrowser


class ListaTiendas:
    def __init__(self):
        self.cabeza = None
        self.ultimo = None
        self.tamanio = 0

    def agregarTienda(self, tienda, zona, envios):
        nueva_tienda = Tienda(tienda, zona)
        nueva_tienda.envios = envios
        if self.cabeza is None:
            self.cabeza = nueva_tienda
            self.ultimo = nueva_tienda
            self.cabeza.next = nueva_tienda
            self.tamanio += 1
        else:
            self.ultimo.next = nueva_tienda
            self.ultimo = nueva_tienda
            self.ultimo.next = self.cabeza
            self.tamanio += 1

    def imprimirTiendas(self):
        current: Tienda = self.cabeza
        while True:
            print(f"-------Tienda: {current.tienda}, Zona:  {current.zona}---------------")
            aux = current.envios.cabeza
            for i in range(current.envios.tamanio):
                print(f"\tCliente:  {aux.cliente}, Direccion:  {aux.direccion},Estado: {aux.estado}")
                aux = aux.next
            if current.next == self.cabeza:
                break
            current = current.next

    def Graficar(self):
        contador=0
        contador2=0
        graficar = "digraph G { \n"
        graficar += "node[shape=box] \n"
        graficar += "label= \"Tiendas y Envios\" \n"
        auxiliar: Tienda = self.cabeza
        for envio in range(self.tamanio):
            nodotienda = "tienda" + str(contador)
            contador += 1
            graficar += nodotienda + "[label=\"Tienda: "+auxiliar.tienda+" \nzona: " + auxiliar.zona + " \"] \n"

            temp = auxiliar.envios.cabeza
            for i in range(auxiliar.envios.tamanio):
                nodoenvio = "envio"+str(contador2)
                contador2 += 1
                graficar += nodoenvio + "[label=\"Cliente: " + temp.cliente + " \nDireccion: " + temp.direccion + " \"] \n"
                temp = temp.next
            auxiliar = auxiliar.next

        aux: Tienda = self.cabeza
        contador = 0
        contador2 = 0
        for i in range(self.tamanio):
            nodotienda = "tienda" + str(contador)
            contadorsiguiente = contador + 1
            nodosiguientetienda = "tienda" + str(contadorsiguiente)
            if aux != self.ultimo:
                graficar += "{rank=same; " + nodotienda + " ->" + nodosiguientetienda + "}\n"
            contador += 1
            temp = aux.envios.cabeza
            for i in range(aux.envios.tamanio):
                print(i)
                nodoenvio = "envio"+str(contador2)
                contadorsiguiente = contador2 + 1
                nodosiguienteenvio = "envio" + str(contadorsiguiente)
                if temp == aux.envios.cabeza:
                    graficar += "{ " + nodotienda + " ->" + nodoenvio + "}\n"
                    graficar += "{ " + nodoenvio + " ->" + nodosiguienteenvio + "}\n"
                else:
                    if temp != aux.envios.ultimo:
                        graficar += "{ " + nodoenvio + " ->" + nodosiguienteenvio + "}\n"
                temp = temp.next
                contador2 += 1
            aux = aux.next
        graficar += "}"
        dot = "tiendas.txt"
        with open(dot, 'w') as grafo:
            grafo.write(graficar)
        result = "tiendas.pdf"
        os.system("dot -Tpdf " + dot + " -o " + result)
        webbrowser.open(result)
